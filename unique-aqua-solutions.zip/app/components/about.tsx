"use client"

import { Target, Eye } from "lucide-react"

export default function About() {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">About Unique Aqua Solutions</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Leading water treatment solutions provider since 2001, serving industries across India with innovative and
            cost-effective technologies.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <img src="/placeholder.svg?height=400&width=600" alt="Our Facility" className="rounded-xl shadow-lg" />
          </div>
          <div className="space-y-6">
            <p className="text-gray-700 leading-relaxed">
              Established in 2001 at Ludhiana, Punjab, India, Unique Aqua Solutions is a leading manufacturer and trader
              of premium quality water treatment equipment. Under the visionary leadership of Mr. Rajnish Bandhu
              (Director), we have achieved remarkable success across the nation.
            </p>
            <p className="text-gray-700 leading-relaxed">
              We specialize in manufacturing Automatic Industrial Water Softener Plants, Commercial Effluent Treatment
              Plants, Industrial Reverse Osmosis Plants, and various water treatment chemicals. Our products are highly
              appreciated for their optimum performance, easy maintenance, and high durability.
            </p>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <div className="bg-blue-50 p-8 rounded-xl">
            <div className="flex items-center mb-4">
              <Eye className="w-8 h-8 text-blue-600 mr-3" />
              <h3 className="text-2xl font-bold text-gray-800">Our Vision</h3>
            </div>
            <p className="text-gray-700 leading-relaxed">
              To be a socially responsible and environmentally friendly water treatment brand making a difference in
              people's lives by providing the best water treatment products and services.
            </p>
          </div>

          <div className="bg-green-50 p-8 rounded-xl">
            <div className="flex items-center mb-4">
              <Target className="w-8 h-8 text-green-600 mr-3" />
              <h3 className="text-2xl font-bold text-gray-800">Our Mission</h3>
            </div>
            <p className="text-gray-700 leading-relaxed">
              To improve the quality of water that was wasted in the past and maintain the quality of water we have in
              the present, while working on future drinking water requirements through innovative treatment products.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
