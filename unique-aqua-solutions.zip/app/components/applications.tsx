"use client"

import { Droplets, Waves, Factory, Shirt, Pill, Recycle, Zap, Cpu, Power, Leaf } from "lucide-react"

const applications = [
  { icon: Droplets, title: "Drinking Water", color: "bg-blue-100 text-blue-600" },
  { icon: Waves, title: "Swimming Pool Filtration", color: "bg-cyan-100 text-cyan-600" },
  { icon: Factory, title: "Cooling Tower & Boiler Feed", color: "bg-gray-100 text-gray-600" },
  { icon: Factory, title: "Manufacturing", color: "bg-orange-100 text-orange-600" },
  { icon: Shirt, title: "Textiles Processing", color: "bg-purple-100 text-purple-600" },
  { icon: Pill, title: "Pharmaceutical Products", color: "bg-green-100 text-green-600" },
  { icon: Recycle, title: "Water Recycling", color: "bg-emerald-100 text-emerald-600" },
  { icon: Recycle, title: "Waste Water Disposal", color: "bg-red-100 text-red-600" },
  { icon: Zap, title: "Pressure Boosting", color: "bg-yellow-100 text-yellow-600" },
  { icon: Cpu, title: "Semiconductor & Electronics", color: "bg-indigo-100 text-indigo-600" },
  { icon: Power, title: "Power Generation", color: "bg-pink-100 text-pink-600" },
  { icon: Leaf, title: "ETP/STP", color: "bg-lime-100 text-lime-600" },
]

export default function Applications() {
  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">Applications</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Our water treatment solutions serve diverse industries and applications across various sectors
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
          {applications.map((app, index) => {
            const IconComponent = app.icon
            return (
              <div
                key={index}
                className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-all duration-300 hover:scale-105 group text-center"
              >
                <div
                  className={`w-12 h-12 rounded-lg ${app.color} flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform`}
                >
                  <IconComponent className="w-6 h-6" />
                </div>
                <h3 className="text-sm font-semibold text-gray-800 leading-tight">{app.title}</h3>
              </div>
            )
          })}
        </div>

        <div className="text-center mt-12">
          <p className="text-lg text-gray-600">
            We are the leaders in water and waste water treatment in Ludhiana, Punjab, India, providing cost-effective
            solutions using innovative technologies.
          </p>
        </div>
      </div>
    </section>
  )
}
