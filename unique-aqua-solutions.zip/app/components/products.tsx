"use client"

import Link from "next/link"
import { ArrowRight, Droplets, Factory, Zap, Beaker, Recycle, Settings } from "lucide-react"

const productCategories = [
  {
    title: "Industrial Reverse Osmosis Plant",
    icon: Droplets,
    image: "/placeholder.svg?height=300&width=400",
    description: "High-efficiency RO systems for industrial applications",
  },
  {
    title: "Sewage Treatment Plant",
    icon: Recycle,
    image: "/placeholder.svg?height=300&width=400",
    description: "Advanced sewage treatment solutions for municipalities",
  },
  {
    title: "Water Softener Plant",
    icon: Factory,
    image: "/placeholder.svg?height=300&width=400",
    description: "Automatic water softening systems for hard water treatment",
  },
  {
    title: "Water Treatment Chemical",
    icon: Beaker,
    image: "/placeholder.svg?height=300&width=400",
    description: "Premium chemicals for water treatment processes",
  },
  {
    title: "Effluent Treatment Plant",
    icon: Zap,
    image: "/placeholder.svg?height=300&width=400",
    description: "Complete effluent treatment solutions for industries",
  },
  {
    title: "Dosing Pump",
    icon: Settings,
    image: "/placeholder.svg?height=300&width=400",
    description: "Precision dosing pumps for chemical treatment",
  },
]

export default function Products() {
  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">Our Products</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Comprehensive range of water treatment solutions designed to meet diverse industrial and commercial needs
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {productCategories.map((product, index) => {
            const IconComponent = product.icon
            return (
              <div
                key={index}
                className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 hover:scale-105 group"
              >
                <div className="relative overflow-hidden">
                  <img
                    src={product.image || "/placeholder.svg"}
                    alt={product.title}
                    className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute top-4 left-4 bg-blue-600 p-2 rounded-lg">
                    <IconComponent className="w-6 h-6 text-white" />
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-800 mb-2">{product.title}</h3>
                  <p className="text-gray-600 mb-4">{product.description}</p>
                  <Link
                    href="/products"
                    className="text-blue-600 hover:text-blue-700 font-semibold flex items-center gap-2 group-hover:gap-3 transition-all"
                  >
                    Learn More <ArrowRight className="w-4 h-4" />
                  </Link>
                </div>
              </div>
            )
          })}
        </div>

        <div className="text-center">
          <Link
            href="/products"
            className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-lg font-semibold inline-flex items-center gap-2 transition-all duration-300 hover:scale-105"
          >
            View All Products <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      </div>
    </section>
  )
}
