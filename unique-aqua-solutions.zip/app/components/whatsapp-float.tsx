"use client"

import { useState } from "react"
import { MessageCircle, X } from "lucide-react"

export default function WhatsAppFloat() {
  const [showPopup, setShowPopup] = useState(false)

  const handleWhatsAppClick = () => {
    const message = encodeURIComponent(
      "Hi! I'm interested in your water treatment solutions. Could you please provide more information?",
    )
    window.open(`https://wa.me/919569360550?text=${message}`, "_blank")
  }

  return (
    <>
      {/* WhatsApp Float Button */}
      <div className="fixed bottom-6 left-6 z-50">
        <div className="relative">
          {/* Popup */}
          {showPopup && (
            <div className="absolute bottom-16 left-0 bg-white p-4 rounded-lg shadow-xl border w-64 animate-in slide-in-from-bottom-2">
              <div className="flex justify-between items-start mb-2">
                <h4 className="font-semibold text-gray-800">Need Help?</h4>
                <button onClick={() => setShowPopup(false)} className="text-gray-400 hover:text-gray-600">
                  <X className="w-4 h-4" />
                </button>
              </div>
              <p className="text-sm text-gray-600 mb-3">Chat with us on WhatsApp for instant support and quotes!</p>
              <button
                onClick={handleWhatsAppClick}
                className="w-full bg-green-500 hover:bg-green-600 text-white py-2 px-4 rounded-lg text-sm font-medium transition-colors"
              >
                Start Chat
              </button>
            </div>
          )}

          {/* WhatsApp Button */}
          <button
            onClick={handleWhatsAppClick}
            onMouseEnter={() => setShowPopup(true)}
            onMouseLeave={() => setShowPopup(false)}
            className="bg-green-500 hover:bg-green-600 text-white p-4 rounded-full shadow-lg transition-all duration-300 hover:scale-110 group"
            aria-label="Contact us on WhatsApp"
          >
            <MessageCircle className="w-6 h-6" />
          </button>
        </div>
      </div>
    </>
  )
}
