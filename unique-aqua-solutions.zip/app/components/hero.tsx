"use client"

import Link from "next/link"
import { ArrowRight, Award, Users, Clock } from "lucide-react"

export default function Hero() {
  return (
    <section className="bg-gradient-to-br from-blue-50 to-cyan-50 py-20">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="text-4xl lg:text-6xl font-bold text-gray-800 leading-tight">
                Premium Water Treatment
                <span className="text-blue-600"> Solutions</span>
              </h1>
              <p className="text-xl text-gray-600 leading-relaxed">
                Established in 2001, we provide cutting-edge water treatment systems for industrial, commercial, and
                residential applications across India.
              </p>
            </div>

            <div className="flex flex-wrap gap-4">
              <Link
                href="/products"
                className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-lg font-semibold flex items-center gap-2 transition-all duration-300 hover:scale-105"
              >
                View Products <ArrowRight className="w-5 h-5" />
              </Link>
              <Link
                href="/quote"
                className="border-2 border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white px-8 py-4 rounded-lg font-semibold transition-all duration-300"
              >
                Get Quote
              </Link>
            </div>

            <div className="grid grid-cols-3 gap-6 pt-8">
              <div className="text-center">
                <Award className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-800">23+</div>
                <div className="text-sm text-gray-600">Years Experience</div>
              </div>
              <div className="text-center">
                <Users className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-800">1000+</div>
                <div className="text-sm text-gray-600">Happy Clients</div>
              </div>
              <div className="text-center">
                <Clock className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-800">24/7</div>
                <div className="text-sm text-gray-600">Support</div>
              </div>
            </div>
          </div>

          <div className="relative">
            <img
              src="/placeholder.svg?height=600&width=800"
              alt="Water Treatment Plant"
              className="rounded-2xl shadow-2xl"
            />
            <div className="absolute -bottom-6 -left-6 bg-white p-6 rounded-xl shadow-lg">
              <div className="text-sm text-gray-600">Trusted by</div>
              <div className="text-2xl font-bold text-blue-600">Industries Nationwide</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
