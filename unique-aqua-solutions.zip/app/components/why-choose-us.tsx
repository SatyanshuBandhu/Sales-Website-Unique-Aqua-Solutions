"use client"

import { Building, Users, Clock, Truck, Globe, DollarSign, Settings } from "lucide-react"

const reasons = [
  {
    icon: Building,
    title: "Robust Infrastructural Base",
    description: "State-of-the-art manufacturing facilities with modern equipment",
  },
  {
    icon: Users,
    title: "Highly Skilled Team",
    description: "Expert professionals with years of industry experience",
  },
  {
    icon: Clock,
    title: "Timely Delivery",
    description: "Committed to delivering projects on schedule",
  },
  {
    icon: Truck,
    title: "Bulk Requirements",
    description: "Capability to handle large-scale industrial orders",
  },
  {
    icon: Globe,
    title: "Wide Distribution Network",
    description: "Pan-India network of dealers and service centers",
  },
  {
    icon: DollarSign,
    title: "Affordable Pricing",
    description: "Competitive prices without compromising on quality",
  },
  {
    icon: Settings,
    title: "Customization Facility",
    description: "Tailored solutions to meet specific requirements",
  },
]

export default function WhyChooseUs() {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">Why Choose Us?</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We have gained a reputed position in this domain by providing a wide range of quality products and
            exceptional services
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {reasons.map((reason, index) => {
            const IconComponent = reason.icon
            return (
              <div
                key={index}
                className="bg-gradient-to-br from-blue-50 to-cyan-50 p-6 rounded-xl hover:shadow-lg transition-all duration-300 hover:scale-105 group"
              >
                <div className="bg-blue-600 w-12 h-12 rounded-lg flex items-center justify-center mb-4 group-hover:bg-blue-700 transition-colors">
                  <IconComponent className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-lg font-bold text-gray-800 mb-2">{reason.title}</h3>
                <p className="text-gray-600 text-sm">{reason.description}</p>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
