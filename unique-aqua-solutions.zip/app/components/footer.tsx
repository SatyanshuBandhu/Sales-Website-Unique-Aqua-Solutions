"use client"

import Link from "next/link"
import { Droplets, Phone, Mail, MapPin } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-16">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Droplets className="w-8 h-8 text-blue-400" />
              <div>
                <h3 className="text-xl font-bold">Unique Aqua Solutions</h3>
                <p className="text-sm text-gray-400">Since 2001</p>
              </div>
            </div>
            <p className="text-gray-300 text-sm leading-relaxed">
              Leading manufacturer and trader of premium quality water treatment equipment, serving industries across
              India with innovative solutions.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-gray-300 hover:text-blue-400 transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/products" className="text-gray-300 hover:text-blue-400 transition-colors">
                  Products
                </Link>
              </li>
              <li>
                <Link href="#about" className="text-gray-300 hover:text-blue-400 transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="#contact" className="text-gray-300 hover:text-blue-400 transition-colors">
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          {/* Products */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Our Products</h4>
            <ul className="space-y-2 text-sm">
              <li className="text-gray-300">RO Plants</li>
              <li className="text-gray-300">Water Softeners</li>
              <li className="text-gray-300">ETP/STP</li>
              <li className="text-gray-300">Dosing Pumps</li>
              <li className="text-gray-300">Treatment Chemicals</li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Contact Info</h4>
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-blue-400" />
                <a href="tel:+919569360550" className="text-gray-300 hover:text-blue-400 transition-colors">
                  +91 9569360550
                </a>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-blue-400" />
                <a
                  href="mailto:info@uniqueaquasolutions.com"
                  className="text-gray-300 hover:text-blue-400 transition-colors"
                >
                  info@uniqueaquasolutions.com
                </a>
              </div>
              <div className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-blue-400 mt-1" />
                <span className="text-gray-300">Ludhiana, Punjab, India</span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8 text-center">
          <p className="text-gray-400">
            © 2024 Unique Aqua Solutions. All rights reserved. | Designed with care for water treatment excellence.
          </p>
        </div>
      </div>
    </footer>
  )
}
