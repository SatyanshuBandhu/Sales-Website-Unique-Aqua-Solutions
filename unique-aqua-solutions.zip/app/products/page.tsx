"use client"

import { useState } from "react"
import Link from "next/link"
import Header from "../components/header"
import Footer from "../components/footer"
import WhatsAppFloat from "../components/whatsapp-float"
import { ArrowLeft } from "lucide-react"

const productCategories = [
  {
    title: "Industrial Reverse Osmosis Plant",
    products: [
      { name: "Industrial RO Plant 1000 LPH", image: "/placeholder.svg?height=300&width=400" },
      { name: "Industrial RO Plant 2000 LPH", image: "/placeholder.svg?height=300&width=400" },
      { name: "Industrial RO Plant 5000 LPH", image: "/placeholder.svg?height=300&width=400" },
    ],
  },
  {
    title: "Automatic Industrial Water Softener Plant",
    products: [
      { name: "Automatic Water Softener Plant", image: "/placeholder.svg?height=300&width=400" },
      { name: "Mineral Water Carbonated Soft Drinks Plant", image: "/placeholder.svg?height=300&width=400" },
      { name: "Hard Water Softener", image: "/placeholder.svg?height=300&width=400" },
    ],
  },
  {
    title: "Water Treatment Chemical",
    products: [
      { name: "RO Antiscalant Chemical", image: "/placeholder.svg?height=300&width=400" },
      { name: "Cooling Water Treatment Chemical", image: "/placeholder.svg?height=300&width=400" },
      { name: "Boilers Water Treatment", image: "/placeholder.svg?height=300&width=400" },
      { name: "Effluent Water Treatment Chemical", image: "/placeholder.svg?height=300&width=400" },
      { name: "Fire Side Chemical", image: "/placeholder.svg?height=300&width=400" },
    ],
  },
  {
    title: "Effluent Treatment Plant",
    products: [
      { name: "Industrial ETP Plant", image: "/placeholder.svg?height=300&width=400" },
      { name: "Commercial ETP Plant", image: "/placeholder.svg?height=300&width=400" },
    ],
  },
  {
    title: "Dosing Pump",
    products: [
      { name: "ETP and STP Dosing Pump", image: "/placeholder.svg?height=300&width=400" },
      { name: "Dosing Pump ETP", image: "/placeholder.svg?height=300&width=400" },
      { name: "Chemical Dosing Pump", image: "/placeholder.svg?height=300&width=400" },
    ],
  },
  {
    title: "Water Softener Plant",
    products: [
      { name: "Water Softener Plant", image: "/placeholder.svg?height=300&width=400" },
      { name: "Duplex Water Softener", image: "/placeholder.svg?height=300&width=400" },
    ],
  },
  {
    title: "Sewage Treatment Plant",
    products: [
      { name: "Municipal STP Plant", image: "/placeholder.svg?height=300&width=400" },
      { name: "Industrial STP Plant", image: "/placeholder.svg?height=300&width=400" },
    ],
  },
]

export default function ProductsPage() {
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [searchTerm, setSearchTerm] = useState("")

  const filteredCategories = productCategories.filter((category) => {
    if (selectedCategory === "All") return true
    return category.title === selectedCategory
  })

  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-50 to-cyan-50 py-16">
        <div className="container mx-auto px-4">
          <div className="flex items-center gap-4 mb-6">
            <Link href="/" className="flex items-center gap-2 text-blue-600 hover:text-blue-700 transition-colors">
              <ArrowLeft className="w-5 h-5" />
              Back to Home
            </Link>
          </div>

          <div className="text-center">
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-800 mb-4">Our Products</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Comprehensive range of water treatment solutions for all your industrial and commercial needs
            </p>
          </div>
        </div>
      </section>

      {/* Filters */}
      <section className="py-8 bg-white border-b">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => setSelectedCategory("All")}
                className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                  selectedCategory === "All" ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                All Products
              </button>
              {productCategories.map((category) => (
                <button
                  key={category.title}
                  onClick={() => setSelectedCategory(category.title)}
                  className={`px-4 py-2 rounded-lg font-medium transition-colors text-sm ${
                    selectedCategory === category.title
                      ? "bg-blue-600 text-white"
                      : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                  }`}
                >
                  {category.title}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Products Grid */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          {filteredCategories.map((category) => (
            <div key={category.title} className="mb-16">
              <h2 className="text-3xl font-bold text-gray-800 mb-8 text-center">{category.title}</h2>

              <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {category.products.map((product, index) => (
                  <div
                    key={index}
                    className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 hover:scale-105 group border"
                  >
                    <div className="relative overflow-hidden">
                      <img
                        src={product.image || "/placeholder.svg"}
                        alt={product.name}
                        className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-300"
                      />
                    </div>
                    <div className="p-6">
                      <h3 className="text-lg font-bold text-gray-800 mb-4">{product.name}</h3>
                      <div className="flex gap-2">
                        <Link
                          href="/quote"
                          className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg font-medium transition-colors text-center"
                        >
                          Get Quote
                        </Link>
                        <button className="border border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white py-2 px-4 rounded-lg font-medium transition-colors">
                          Details
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      <Footer />
      <WhatsAppFloat />
    </div>
  )
}
