"use client"

import { useState, useEffect } from "react"
import { ArrowUp } from "lucide-react"
import Header from "./components/header"
import Hero from "./components/hero"
import About from "./components/about"
import Products from "./components/products"
import WhyChooseUs from "./components/why-choose-us"
import Applications from "./components/applications"
import Contact from "./components/contact"
import Footer from "./components/footer"
import WhatsAppFloat from "./components/whatsapp-float"

export default function HomePage() {
  const [showScrollTop, setShowScrollTop] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 300)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  return (
    <div className="min-h-screen bg-white">
      <Header />
      <Hero />
      <About />
      <Products />
      <WhyChooseUs />
      <Applications />
      <Contact />
      <Footer />
      <WhatsAppFloat />

      {/* Scroll to Top Button */}
      {showScrollTop && (
        <button
          onClick={scrollToTop}
          className="fixed bottom-6 right-6 z-40 bg-blue-600 hover:bg-blue-700 text-white p-3 rounded-full shadow-lg transition-all duration-300 hover:scale-110"
          aria-label="Scroll to top"
        >
          <ArrowUp className="w-6 h-6" />
        </button>
      )}
    </div>
  )
}
